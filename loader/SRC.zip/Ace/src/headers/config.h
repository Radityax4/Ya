#pragma once

#define HTTP_SERVER "185.172.111.225"
#define HTTP_PORT 80

#define TFTP_SERVER "185.172.111.225"
